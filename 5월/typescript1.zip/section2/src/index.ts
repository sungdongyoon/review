function func1(): string {
  return "hello";
}

function func2(): void {
  console.log("hello");
}

let a: void;
a = 1;
a = "a";
a = undefined;
a = null;

let b: never;
b = 1;
b = "a";
b = undefined;
b = null;