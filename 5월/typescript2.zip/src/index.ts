// 타입별칭 정의

type Admin = {
  tag: "ADMIN";
  name: string;
  kickcount: number;
};

type Member = {
  tag: "MEMBER";
  name: string;
  point: number;
};

type Guest = {
  tag: "GUEST";
  name: string;
  visitcount: number
};


// 정의된 타입별칭을 유니온타입으로 정리
type User = Admin | Member | Guest;

// function login(user: User) {
//   if("kickcount" in user) {
//     console.log(`${user.name}님 현재까지 ${user.kickcount}명을 추방했습니다`);
//   } else if("point" in user) {
//     console.log(`${user.name}님 현재까지 ${user.point}점을 모았습니다`);
//   } else {
//     console.log(`${user.name}님 현재까지 ${user.visitcount}번 오셨습니다`); 
//   }
// }

function login(user: User) {
  switch (user.tag) {
    case "ADMIN": {
      console.log(`${user.name}님 현재까지 ${user.kickcount}명을 추방했습니다`);
      break;
    }
    case "MEMBER": {
      console.log(`${user.name}님 현재까지 ${user.point}점을 모았습니다`);
      break;
    }
    case "GUEST": {
      console.log(`${user.name}님 현재까지 ${user.visitcount}번 오셨습니다`);
      break;
    }
  }
}