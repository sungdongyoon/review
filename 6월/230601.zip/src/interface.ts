// 인터페이스
// 선택적 옵션, 읽기전용 가능

interface Person {
  readonly name: string;
  age?: number;
  sayHi: () => void;
}

const person: Person = {
  name: "홍길동",
  sayHi: () => {}
}


// 인터페이스 확장

interface Animal {
  name: string;
  age: number;
};


// 기본적인 Animal 인터페이스에서 isBark값을 추가한 것
interface Dog extends Animal {
  isBark: boolean;
}

const dog: Dog = {
  name: "뽀삐",
  age: 10,
  isBark: true
}

interface Cat {
  name: string;
  age: number;
  isScratch: boolean;
}

interface Chicken {
  name: string;
  age: number;
  isFly: boolean;
}



// type Person1 = {
//   name: string;
// }

// type Person1 = {
//   age: number;
// }


interface Person2 {
  name: string;
}

interface Person2 {
  age: number;
}

// 각 Person2의 값이 합쳐져서 person2에 적용 가능
const person2: Person2 = {
  name: "홍길동",
  age: 20
}