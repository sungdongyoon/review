// 필드안에 초기값을 반드시 명시해주어야 한다


// 타입스크립트 클래스의 필드값은 기본적으로 public이라는 디폴트 값을 가지고 있다
// 필드값에 접근하지 못하도록 하기 위해서는 private이라는 값을 적용하면 된다

class Employee {
  // 필드
  public name: string = "";
  public age: number = 0;
  public position: string = "";

  // 생성자
  constructor(name: string, age: number, position: string) {
    this.name = name;
    this.age = age;
    this.position = position;
  }

  // 메서드
  work() {
    console.log("워커홀릭");
  }
}

const employee2 = new Employee("영심이", 13, "developer");
employee2.name = "빵심이";
employee2.age = 15;
employee2.position = "publisher";




// 타입스크립트에서도 클래스 상속 가능!


class ExecutiveOfficer extends Employee {
  // 필드
  officeNumber: number = 1;
  
  // 생성자
  constructor(name: string, age: number, position: string, officeNumber: number) {
    super(name, age, position);
    this.officeNumber = officeNumber;
  }

  // 메서드
  func() {
    this.name;
    this.age;
  }
}


// 인터페이스를 구현하는 클래스

interface CharacterInterface {
  name: string;
  moveSpeed: number;
  move(): void;
}

// 타입스크립트에서 클래스를 생성할 때, 사용하는 implement는 해당 인터페이스를 생성하고자 하는 클래스에서
// 모두 만족하도록 구현하게끔 만드는 키워드

class Character implements CharacterInterface {
  constructor(
    public name: string,
    public moveSpeed: number,
    // private extra: string
  ) {}

  move(): void {
    console.log(`${this.moveSpeed}속도로 이동`)
  }
}

