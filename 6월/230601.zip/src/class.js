// 자바스크립트에서 클래스를 선언할 때는 반드시 class 키워드 사용
// 클래스는 객체를 프로토타입의 객체를 선언하는 일종의 틀 = 붕어빵 틀


class Student {
  // 필드
  name;
  grade;
  age;

  // 생성자
  constructor(name, grade, age) {
    this.name = name;
    this.grade = grade;
    this.age = age;
  }

  study() {
    console.log("열심히 공부하는 친구");
  }

  introduce() {
    console.log(`안녕하세요 ${this.name} 입니다`)
  }
}

// 자바스크립트 class에서도 상속 가능

class StudentDeveloper extends Student {
  // 필드
  favoriteSkill;

  // 생성자
  constructor(name, grade, age, favoriteSkill) {
    this.favoriteSkill = favoriteSkill;
  }

  // 신규 메서드
  programming() {
    console.log(`${this.favoriteSkill}로 프로그래밍 할 수 있습니다.`)
  }
}

const studentC = new Student("빵순이", "A+", 21);
console.log(studentC);

