// 사용자 정의 타입

type Dog = {
  name: string;
  isBarked: boolean;
};

type Cat = {
  name: string;
  isScratch: boolean;
}

// 유니온 타입으로 Animal 정의
type Animal = Dog | Cat;

// function warning(animal: Animal) {
//   // in : 타입 안에서 어떤 값을 찾을 때 사용
//   if("isBark" in animal) {
//     console.log(animal.isBark ? "짖습니다" : "짖지 않습니다");
//   } else if("isScratch" in animal) {
//     console.log(animal.isScratch ? "할큅니다" : "할퀴지 않습니다");
//   }
// }

// 타입의 키값을 바꾸는 경우 함수가 작동하지 않는다


// isDog함수의 aniaml 매개변수가 Dog타입인지 아닌지를 확인하는 사용자 정의 타입
function isDog(animal: Animal): animal is Dog {
  return (animal as Dog).isBarked !== undefined;
};
// 매개변수를 Animal로 정의, 반환값을 Dog로 단언,
// 반환값은 결국 Dog타입으로 정의된 animal의 isBarked가 undefined가 아니면 animal은 Dog타입이 된다 라는 뜻이다

// isCat함수의 animal 매개변수가 Cat타입인지 아닌지를 확인하는 사용자 정의 타입
function isCat(animal: Animal): animal is Cat {
  return (animal as Cat).isScratch !== undefined;
};
// 매개변수를 Animal로 정의, 반환값을 Cat으로 단언,
// 반환값은 결국 Cat타입으로 정의된 animal의 isScratch가 undefined가 아니면 animal은 Cat타입이 된다 라는 뜻이다



// 반환값은 매개변수 뒤에 단언
// return 뒤에 반환값이 참이라면 사전에 정의한 반환값이 되는 것이다

function warning(animal: Animal) {
  if(isDog(animal)) {
    console.log(animal.isBarked ? "짖습니다" : "짖지 않습니다");
  } else {
    console.log(animal.isScratch ? "할큅니다" : "할퀴지 않습니다");
  }
}