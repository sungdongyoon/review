// 타입스크립트 map함수 정의

function map<T, U>(arr: T[], callback: (item: T) => U): U[] {
  let result = [];
  for(let i = 0; i < arr.length; i++) {
    result.push(callback(arr[i]));
  }
  return result;
}

const arr = [1, 2, 3];
map(arr, (item) => item.toString());