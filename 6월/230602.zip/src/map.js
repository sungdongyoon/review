let arr = [1, 2, 3, 4, 5];

let newArr = arr.map((item) => item * 3);

console.log(newArr);

let arr1 = [
  {name: "황병선", hobby: "영화"},
  {name: "민혜린", hobby: "노래"},
  {name: "이다미", hobby: "축구"},
  {name: "김가을", hobby: "야구"}
];

let newArr1 = arr1.map((item) => item.hobby);
console.log(newArr1);