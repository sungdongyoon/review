// <T> : 타입변수
// 제네릭 함수의 형태
function func<T>(value: T): T {
  return value;
}

// 튜플타입 적용
let arr = func<[number, number, number]>([1, 2, 3]);

let num = func(10);
num.toFixed();

let str = func("string");




// 타입좁히기
if(typeof num === "number") {
  num.toFixed();
}

// 제네릭 함수

// 타입변수 <T> 응용
function swap<T, U>(a: T, b: U) {
  return [b, a];
}

const [a, b] = swap(1, 2); // a = 2, b = 1

const [c, d] = swap("1", 2);



// data 매개변수는 배열객체 타입, <T>는 0번째 인덱스 값만 가져와라, 0번째 값은 T고 나머지 뒤의 값은 별 신경을 안쓴다
function returnFirstValue<T>(data: [T, ...unknown[]]) {
  return data[0];
};

let num1 = returnFirstValue([0, 1, 2]);

let str1 = returnFirstValue([1, "hello", "hi"]);




function getLength<T extends { length: number }>(data: T) {
  return data.length;
}

getLength("123");
getLength([1, 2, 3]);
getLength({length: 1});