// 인덱스드 엑세스 타입

interface Post {
  title: string;
  content: string;
  author: {
    id: number;
    name: string;
    age: number;
  };
};

const post: Post = {
  title: "우산렌탈 타이틀",
  content: "우산렌탈 게시글",
  author: {
    id: 1,
    name: "황영재",
    age: 20
  }
}

function printAuthorInfo(author: Post["author"]) {
  console.log(`${author.id} - ${author.name}`);
}


// keyof 연산자

interface Person {
  name: string;
  age: number;
  location: string;
}

function getPropertykey(person: Person, key: keyof Person) {
  return person[key];
}

const person: Person = {
  name: "홍길동",
  age: 27,
  location: "서울"
}



// 맵드타입

interface User7 {
  id: number;
  name: string;
  age: number;
}

type PartialUser = {
  [key in "id" | "name" | "age"]?: User7[key];
}
// key가 "id"일 때, id: User7[id] : number
// key가 "name"일 때, id: User7[name] : string
// key가 "age"일 때, id: User7[age] : number



function fetchUser(): User7 {
  return {
    id: 1,
    name: "슛돌이",
    age: 40
  }
}

function updateUser(user: PartialUser) {
  // 서버로부터 받아온 사용자의 데이터를 업데이트하도록 하는 실행문
}

updateUser({
  age: 24
})



// 템플릿 리터럴 타입

type Color = "red" | "black" | "green";
type Animal = "dog" | "cat" | "chicken";

type ColroedAnimal = `${Color}-${Animal}`;