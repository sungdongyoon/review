const arr = [1, 2, 3];

arr.forEach((item, idx) => {
  console.log(`${idx}번째 요소: ${item}`);
})