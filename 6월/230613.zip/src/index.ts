import { Bird, Fish } from "./BirdAndFish";
import { flyOrSwim } from "./FlyOrSwim";

[new Bird, new Fish].forEach(flyOrSwim)