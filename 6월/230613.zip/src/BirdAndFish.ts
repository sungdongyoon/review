export class Bird {fly() {console.log(`I'm flying`)}}
export class Fish {swim() {console.log(`I'm swiming`)}}