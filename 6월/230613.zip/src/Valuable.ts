import { IValuable } from "./IValuable";

export class Valualbe<T> implements IValuable<T> {
  constructor(public value: T) {}
}

export{IValuable}