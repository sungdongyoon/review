// import { IValuable } from "./Valuable";

// export const printValueT = <T>(o: T): void => console.log(o.value)

// export {IValuable}